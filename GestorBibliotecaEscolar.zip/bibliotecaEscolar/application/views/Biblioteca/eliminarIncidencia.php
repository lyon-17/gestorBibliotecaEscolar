<?php

echo validation_errors();

$attributes = array(
	'class' => 'form-inline',
	);
$eliminar = array(
	'class' => 'form-control',
	'name' => 'eliminar',
	'value' => 'si',
	);
$salir = array(
	'class' => 'form-control',
	'name' => 'salir',
	'value' => 'no',
	);
echo '<div class="container-fluid">';
echo form_open('biblioteca/eliminarIncidencia',$attributes);
	echo '<br/><h3>¿Que incidencia quieres eliminar?</h3>
		<select class="form-control" name="dato">';
			foreach ($incidencias as $incidencias_item):
				$asunto_incidencias = $incidencias_item['asunto'];
				echo '<option value="'.$asunto_incidencias.'">'.$asunto_incidencias.'</option>';
			endforeach;
		echo '</select>
	<input class="btn btn-default" type="submit" name="buscar" value="buscar incidencia"></form><br/>';

if(!empty($incidencia)){
	echo form_open('biblioteca/eliminarIncidencia');

	foreach ($incidencia as $incidencia_item):
		$idPrestamo = $incidencia_item['prestamos_id'];
		$asunto = $incidencia_item['asunto'];
		$descripcion = $incidencia_item['descripcion'];
		$hidden = array('prestamos_id' => $idPrestamo);
		$hiddenAsunto = array('asunto' => $asunto);
		echo form_hidden($hidden).form_hidden($hiddenAsunto).
		'	<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos de la incidencia</h3></div>
				<div class="panel-body">
					<div class="form-group">
						<label>Id del prestamo</label>
						<input type="name" class="form-control" value="'.$idPrestamo.'" disabled>
					</div>
					<div class="form-group">
						<label>Asunto</label>
						<input type="name" class="form-control" value="'.$asunto.'" disabled>
					</div>
					<div class="form-group">
						<label>Descripcion</label>
						<input type="text" name="descripcion" class="form-control" value="'.$descripcion.'" disabled>
					</div>
		</form>';
	endforeach;
	if(!empty($incidencia)){
		echo form_open('biblioteca/eliminarIncidencia',$attributes);
			echo form_hidden($hidden).form_hidden($hiddenAsunto).
			'<br/><b>Estas seguro que quieres eliminar esta incidencia</b>'.form_submit($eliminar).form_submit($salir);
	}
	echo '		</div>
			</div>
		</div>';
	}
?>