<?php

echo validation_errors();

$attributes = array(
	'class' => 'form-inline',
	);

echo '<div class="container-fluid">';
echo form_open('biblioteca/editarEjemplar',$attributes);
	echo '<br/><h3>Indique el codigo del ejemplar</h3>
		<select class="form-control" name="cod_ejemplar">';
			foreach ($ejemplares as $ejemplares_item):
				$e_cod = $ejemplares_item['cod_ejemplar'];
				echo '<option value="'.$e_cod.'">'.$e_cod.'</option>';
			endforeach;
		echo '</select>
	<input class="btn btn-default" type="submit" name="buscar" value="ver ejemplar"></form><br/>';

if(!empty($ejemplar)){
	echo form_open('biblioteca/editarEjemplar');

	foreach ($ejemplar as $ejemplar_item):
		$isbn = $ejemplar_item['libros_ISBN'];
		$cod_ejemplar = $ejemplar_item['cod_ejemplar'];
		$estado = $ejemplar_item['estado'];
		$hidden = array('cod_ejemplar' => $cod_ejemplar);
		echo form_hidden($hidden).
		'	<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos del ejemplar</h3></div>
				<div class="panel-body">
					<div class="form-group">
						<label>Codigo del ejemplar</label>
						<input type="name" class="form-control" value="'.$cod_ejemplar.'" disabled>
					</div>
					<div class="form-group">
						<label>ISBN del libro</label>
						<input type="name" class="form-control" value="'.$isbn.'" disabled>
					</div>
					<div class="form-group">
						<label>Estado</label>
						<input type="name" name="estado" maxlength="120" class="form-control" value="'.$estado.'" required>
					</div>
				</div>
			</div>';
	endforeach;
	echo '<input class="btn btn-default" type="submit" name="editar" value="guardar cambios">';
	}
	echo '</div>';

?>