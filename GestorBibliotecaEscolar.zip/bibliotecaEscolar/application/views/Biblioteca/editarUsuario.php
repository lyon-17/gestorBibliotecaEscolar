<?php

echo validation_errors();

$attributes = array(
	'class' => 'form-inline',
	);
echo '<div class="container-fluid">';
echo form_open('biblioteca/editarUsuario',$attributes);
	echo '<br/><h3>Busqueda</h3>
		<select class="form-control" name="tipo">
			<option value="nombre">nombre</option>
			<option value="DNI">DNI</option>
			<option value="apellidos">Apellidos</option>
			<option value="domicilio">Domicilio</option>
			<option value="curso">Curso</option>
			<option value="numero_c">numero de contacto</option>
			<option value="correo">correo de contacto</option>

		</select>
		<div class="form-group">
			<input class="form-control" name="dato" type="text" value=""><br/>
		</div>
	<input class="btn btn-default" type="submit" name="buscar" value="buscar usuarios"></form><br/>';

if(!empty($usuario)){
	echo form_open('biblioteca/editarUsuario');

	foreach ($usuario as $usuario_item):
		$dni = $usuario_item['DNI'];
		$nombre = $usuario_item['nombre'];
		$apellidos = $usuario_item['apellidos'];
		$domicilio = $usuario_item['domicilio'];
		$curso = $usuario_item['curso'];
		$n_contacto = $usuario_item['n_contacto'];
		$correo = $usuario_item['correo'];
		$hiddenDni = array('dni' => $dni);
		echo form_hidden($hiddenDni).
		'	<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos del usuario</h3></div>
				<div class="panel-body">
					<div class="form-group">
						<label>DNI</label>
						<input type="name" class="form-control" value="'.$dni.'" disabled>
					</div>
					<div class="form-group">
						<label>Nombre</label>
						<input type="name" maxlength="120" name="nombre" class="form-control" value="'.$nombre.'" required>
					</div>
					<div class="form-group">
						<label>Apellidos</label>
						<input type="name" maxlength="120" name="apellidos" class="form-control" value="'.$apellidos.'" required>
					</div>
					<div class="form-group">
						<label>Domicilio</label>
						<input type="name" maxlength="255" name="domicilio" class="form-control" value="'.$domicilio.'" required>
					</div>
					<div class="form-group">
						<label>Curso</label>
						<input type="name" maxlength="120" name="curso" class="form-control" value="'.$curso.'" required>
					</div>
					<div class="form-group">
						<label>Numero de contacto</label>
						<input type="number" minlength="9" maxlength="11" name="n_contacto" class="form-control" value="'.$n_contacto.'" required>
					</div>
					<div class="form-group">
						<label>correo de contacto</label>
						<input type="email" maxlength="120" name="correo" class="form-control" value="'.$correo.'" required>
					</div>
					<input class="btn btn-default" type="submit" name="editar" value="guardar cambios">
				</div>
			</div>';
	endforeach;
	}
	echo '</div>';

?>