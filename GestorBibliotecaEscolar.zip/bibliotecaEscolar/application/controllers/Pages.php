<?php
class Pages extends CI_controller{

	public function view($page = 'home'){
		/*if(!file_exists(APPPATH.'views/pages'.$page.'.php')){
			//File don't exist, show 404 page error.
			show_404();
		}*/
		$data['title'] = ucfirst($page); //Turn the first letter to capital
		$data['hello'] = 'hum, h-hello';
		$this->load->view('templates/header', $data);
		$this->load->view('pages/'.$page,$data);
		$this->load->view('templates/footer');
	}
}

?>