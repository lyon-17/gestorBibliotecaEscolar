<?php

echo '<br/>
			<div class="panel panel-default">
				<div class="panel-heading"><h3>'.$title.'</h3></div>
				<div class="panel-body">
				<br/><table class="table table-striped table-hover">
					<tr>
						<th>Id del prestamo</th>
						<th>Asunto</th>
						<th>Descripcion</th>
					</tr>';
					foreach ($incidencias as $incidencias_item):
					echo '<tr>
							<td>' . $incidencias_item['prestamos_id'] . '</td>'
						 .'<td>' . $incidencias_item['asunto'] . '</td>'
						 .'<td>' . $incidencias_item['descripcion'] . '</td>
						 </tr>';
					endforeach;	
			echo '</table>
				</div>
			</div>';
?>