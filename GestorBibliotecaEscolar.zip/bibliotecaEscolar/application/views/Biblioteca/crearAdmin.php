
<?php
$this->load->helper('form');
echo validation_errors();

$submit = array(
	'name' => 'crearAdmin',
	'value' => 'añadir administrador',
	'class' => 'form-control',
	'style' => 'border-radius:5px; margin: 5px;',
);
$atributtes = array(
	'class' => 'form-inline'
);
echo '<div class="container-fluid">'.
		form_open('biblioteca/crearAdmin',$atributtes).
			'<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos del administrador</h3></div>
				<div class="panel-body">
				<label>Usuario:</label> <select class="form-control" name="usuarios_id">';
					foreach ($usuarios as $usuarios_item):
						$user_id = $usuarios_item['id'];
						$nombre = $usuarios_item['nombre'];
						$apellidos = $usuarios_item['apellidos'];
						echo '<option value="'.$user_id.'">'.$nombre.' '.$apellidos.'</option>';
					endforeach;
		  echo '</select><br/><br/>
				<div class="form-group">
					<label>Nombre de usuario</label>
					<input type="name" name="usuario" maxlength="120" class="form-control" value="" required>
				</div>
				<div class="form-group">
					<label>contraseña del usuario</label>
					<input type="password" name="password" maxlength="120" class="form-control" value="" required>
				</div>
				<div class="form-group">
					<label>vuelve a escribir la contraseña</label>
					<input type="password" name="passwordB" maxlength="120" class="form-control" value="" required>
				</div>
			</div>'.
			form_submit($submit);
	echo '</div>';

?>