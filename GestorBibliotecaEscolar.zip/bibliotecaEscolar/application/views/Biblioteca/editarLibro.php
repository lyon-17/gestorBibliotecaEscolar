<?php

echo validation_errors();

$attributes = array(
	'class' => 'form-inline',
	);
$clase = array(
	'class' => 'form-control'
	);
$opciones = array(
	'titulo' => 'titulo',
	'ISBN' => 'ISBN',
	'autor' => 'autor',
	'cdu' => 'CDU',
	'fecha_publicacion' => 'año',
	);
$dato = array(
	'class' => 'form-control',
	'name' => 'dato',
	);
echo '<div class="container-fluid">';
echo 
	form_open('biblioteca/editarLibro',$attributes).
	'<br/><h3>Busqueda</h3>
			'.form_dropdown('tipo',$opciones,'',$clase).'
		<div class="form-group">'.
			form_input($dato)
		.'<br/></div>
	<input class="btn btn-default" type="submit" name="buscar" value="buscar libros"></form><br/>';

if(!empty($libro)){
	echo form_open('biblioteca/editarLibro');

	foreach ($libro as $libro_item):

	if(empty($isbn)){
		$isbn = $libro_item['ISBN'];
		$titulo = $libro_item['titulo'];
		$autor = $libro_item['autor'];
		$paginas = $libro_item['paginas'];
		$cdu = $libro_item['CDU'];
		$fecha_publicacion = $libro_item['fecha_publicacion'];
		$hidden = array('isbn' => $isbn);
		echo form_hidden($hidden).
		'	<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos del libro</h3></div>
				<div class="panel-body">
				<div class="form-group">
						<label>ISBN</label>
						<input type="name" maxlength="120" class="form-control" value="'.$isbn.'" disabled>
					</div>
					<div class="form-group">
						<label>Titulo</label>
						<input type="name" name="titulo"  maxlength="255" class="form-control" value="'.$titulo.'" required>
					</div>
					<div class="form-group">
						<label>Autor</label>
						<input type="name" name="autor" maxlength="120" class="form-control" value="'.$autor.'" required>
					</div>
					<div class="form-group">
						<label>paginas</label>
						<input type="number" name="paginas" maxlength="11" class="form-control" value="'.$paginas.'">
					</div>
					<div class="form-group">
						<label>cdu</label>
						<input type="name" name="cdu" maxlength="120" class="form-control" value="'.$cdu.'">
					</div>
					<div class="form-group">
						<label>año de publicacion</label>
						<input type="number" name="fecha_p"  maxlength="11" class="form-control" value="'.$fecha_publicacion.'">
					</div>
				</div>
			</div>';
	}
	endforeach;
	}
	if(!empty($libro)){
			echo '<input class="btn btn-default" type="submit" name="editar" value="guardar cambios">';
		}
	echo '</div>';

?>