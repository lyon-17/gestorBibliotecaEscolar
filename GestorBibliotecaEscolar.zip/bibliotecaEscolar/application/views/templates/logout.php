<form method="post" action="../localhost">
	<input type="submit" value="salir">
</form>
