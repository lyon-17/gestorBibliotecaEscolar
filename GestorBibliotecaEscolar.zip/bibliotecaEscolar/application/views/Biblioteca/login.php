<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" context="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <title>Biblioteca</title>

    <link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/font-awesome.min.css') ?>" rel="stylesheet">
</head>
<body style="background-size:100%, 100%; background-image: url(../../../images/fondo.jpg); color: gray;">
    <div class="container-fluid">
	<h1>
		<?php echo $title; ?>
	</h1>
<?php echo validation_errors();

$atributtes = array(
	'class' => 'form-inline',
	);
echo form_open('biblioteca/login',$atributtes); 
		$usuario = array(
			'name' => 'usuario',
			'value' => 'admin1',
			'class' => 'form-contol',
			);
		$password = array(
			'name' => 'password',
			'value' => 'admin',
			'class' => 'form-contol',
			);
		$envio = array(
			'name' => 'entrar',
			'value' => 'entrar',
			'class' => 'form-contol',
			);
	 echo '<label style="margin-right: 25px;">Usuario</label>'.form_input($usuario)
	 .'<br/><label>Contraseña</label>'.form_password($password)
	 .'<br/>'.form_submit($envio);
	 ?>