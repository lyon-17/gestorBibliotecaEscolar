<?php

echo validation_errors();

$attributes = array(
	'class' => 'form-inline',
	);
echo '<div class="container-fluid">';
echo form_open('biblioteca/eliminarUsuario',$attributes);
	echo '<br/><h3>Busqueda</h3>
		<select class="form-control" name="tipo">
			<option value="nombre">nombre</option>
			<option value="DNI">DNI</option>
			<option value="apellidos">Apellidos</option>
			<option value="domicilio">Domicilio</option>
			<option value="curso">Curso</option>
			<option value="numero_c">numero de contacto</option>
			<option value="correo">correo de contacto</option>

		</select>
		<div class="form-group">
			<input class="form-control" name="dato" type="text" value=""><br/>
		</div>
	<input class="btn btn-default" type="submit" name="buscar" value="buscar usuarios"></form><br/>';

if(!empty($usuario)){
	echo form_open('biblioteca/eliminarUsuario');

	foreach ($usuario as $usuario_item):
		$id = $usuario_item['id'];
		$dni = $usuario_item['DNI'];
		$nombre = $usuario_item['nombre'];
		$apellidos = $usuario_item['apellidos'];
		$domicilio = $usuario_item['domicilio'];
		$curso = $usuario_item['curso'];
		$n_contacto = $usuario_item['n_contacto'];
		$correo = $usuario_item['correo'];
		$hidden = array('id' => $id);
		$hiddenDni = array('dni' => $dni);
		echo'<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos del usuario</h3></div>
				<div class="panel-body">
					<div class="form-group">
						<label>DNI</label>
						<input type="name" name="dni" class="form-control" value="'.$dni.'" disabled>
					</div>
					<div class="form-group">
						<label>Nombre</label>
						<input type="name" name="nombre" class="form-control" value="'.$nombre.'" disabled>
					</div>
					<div class="form-group">
						<label>Apellidos</label>
						<input type="name" name="apellidos" class="form-control" value="'.$apellidos.'" disabled>
					</div>
					<div class="form-group">
						<label>Domicilio</label>
						<input type="name" maxlength="255" class="form-control" value="'.$domicilio.'" disabled>
					</div>
					<div class="form-group">
						<label>Curso</label>
						<input type="name" maxlength="120" class="form-control" value="'.$curso.'" disabled>
					</div>
					<div class="form-group">
						<label>Numero de contacto</label>
						<input type="name" name="n_contacto" class="form-control" value="'.$n_contacto.'" disabled>
					</div>
					<div class="form-group">
						<label>correo de contacto</label>
						<input type="name" name="correo" class="form-control" value="'.$correo.'" disabled>
					</div>
				</form>';
	if(!empty($usuario)){
			echo form_open('biblioteca/eliminarUsuario',$attributes).form_hidden($hidden).form_hidden($hiddenDni).'<br/><b>Estas seguro que quieres eliminar este usuario</b><input type="submit" name="eliminar" class="form-control" value="Si">&nbsp;<input type="submit" class="form-control" name="salir" value="No">';
		}
			echo '</div>
			</div>';
		endforeach;
	}
?>