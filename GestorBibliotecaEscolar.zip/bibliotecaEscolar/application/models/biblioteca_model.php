<?php
class Biblioteca_model extends CI_Model{

	public function __construct(){
		//carga la base de datos
		$this->load->database();
		$this->load->dbforge();
	}

	public function comprobarUser($user,$pass){
		$this->db->where('usuario',$user);
		$this->db->where('password',$pass);
		$query = $this->db->get('administradores');
		return $query->result_array();
	}
	/*
	*	 ________________________________________________
	*	|												|
	*	|				Obtencion de datos              |
	*	|_______________________________________________|
	*/
	public function get_biblioteca(){
		
		$this->db->order_by('titulo');
		$query = $this->db->get('libros');
		return $query->result_array();
	}
	public function get_usuarios(){
		$this->db->where('id != 0');
		$this->db->order_by('nombre');
		$query = $this->db->get('usuarios');
		return $query->result_array();
	}
	public function buscar_usuarios($dni,$nombre,$apellidos,$domicilio,$curso,$n_contacto,$correo){
		$this->db->like('DNI',$dni);
		$this->db->like('nombre',$nombre);
		$this->db->like('apellidos',$apellidos);
		$this->db->like('domicilio',$domicilio);
		$this->db->like('curso',$curso);
		$this->db->like('n_contacto',$n_contacto);
		$this->db->like('correo',$correo);
		$this->db->where('id != 0');
		$query = $this->db->get('usuarios');
		return $query->result_array();
	}
	public function buscar_libros($isbn,$titulo,$autor,$paginas,$cdu,$fecha_p){
		$this->db->like('ISBN',$isbn);
		$this->db->like('titulo',$titulo);
		$this->db->like('autor',$autor);
		$this->db->like('paginas',$paginas);
		$this->db->like('CDU',$cdu);
		$this->db->like('fecha_publicacion',$fecha_p);
		$query = $this->db->get('libros');
		return $query->result_array();
	}
	public function buscar_ejemplares($cod_ejemplar,$isbn,$titulo,$estado){
		$this->db->like('cod_ejemplar',$cod_ejemplar);
		$this->db->like('libros_ISBN',$isbn);
		$this->db->like('titulo',$titulo);
		$this->db->like('estado',$estado);

		$this->db->join('libros','libros.ISBN=ejemplares.libros_ISBN');
		$query = $this->db->get('ejemplares');
		return $query->result_array();
	}
	public function buscar_prestamos($nombreUsuario,$apellidosUsuario,$codigoEjemplar,$fechaInicio,$fechaFin){
		$this->db->select('prestamos.id as id_prestamo,usuarios.nombre as nombre,usuarios.apellidos as apellidos,ejemplares_prestamos.ejemplares_cod_ejemplar,ejemplares_prestamos.fecha_inicio,ejemplares_prestamos.fecha_fin,prestamos.finalizado');
		$this->db->from('usuarios');
		$this->db->join('usuarios_prestamos','usuarios.id=usuarios_prestamos.usuarios_id');
		$this->db->join('prestamos','prestamos.id=usuarios_prestamos.prestamos_id');
		$this->db->join('ejemplares_prestamos','ejemplares_prestamos.prestamos_id=prestamos.id');
		$this->db->like('nombre',$nombreUsuario);
		$this->db->like('apellidos',$apellidosUsuario);
		$this->db->like('ejemplares_cod_ejemplar',$codigoEjemplar);
		$this->db->like('fecha_inicio',$fechaInicio);
		$this->db->like('fecha_fin',$fechaFin);
		$this->db->order_by('finalizado','ASC');
		$this->db->order_by('usuarios.nombre' ,'ASC');
		$this->db->order_by('fecha_fin',' ASC');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function get_historial(){
		$this->db->order_by('fecha','desc');
		$query = $this->db->get('historial');
		return $query->result_array();
	}

	public function get_prestamos($clase){
		$this->db->select('prestamos.id as id_prestamo,usuarios.nombre as nombre,usuarios.apellidos as apellidos,ejemplares_prestamos.ejemplares_cod_ejemplar,ejemplares_prestamos.fecha_inicio,ejemplares_prestamos.fecha_fin,prestamos.finalizado');
		$this->db->from('usuarios');
		$this->db->join('usuarios_prestamos','usuarios.id=usuarios_prestamos.usuarios_id');
		$this->db->join('prestamos','prestamos.id=usuarios_prestamos.prestamos_id');
		$this->db->join('ejemplares_prestamos','ejemplares_prestamos.prestamos_id=prestamos.id');
		$this->db->order_by('finalizado','ASC');
		$this->db->order_by('usuarios.nombre' ,'ASC');
		$this->db->order_by('fecha_fin',' ASC');
		if($clase=='activos'){
			$this->db->where('finalizado',0);
			$this->db->where('gratuito',0);
		}
		if($clase=='noFinalizado'){
			$this->db->where('finalizado',0);
			$this->db->where('gratuito',1);
		}
		if($clase=='finalizado'){
			$this->db->where('finalizado',1);
		}
		if($clase=='gratuitos'){
			$this->db->where('gratuito',1);
		}
		$query = $this->db->get();
		return $query->result_array();
	}
	public function get_ejemplares(){
		$this->db->from('ejemplares');
		$this->db->order_by('titulo');
		$this->db->join('libros','libros.ISBN=ejemplares.libros_ISBN');
		$query = $this->db->get();
		return $query->result_array();
	}

	public function get_prestamo($id){
		$this->db->select('prestamos.id as id_prestamo,usuarios.nombre as nombre,usuarios.apellidos as apellidos,ejemplares_prestamos.ejemplares_cod_ejemplar,ejemplares_prestamos.fecha_inicio,ejemplares_prestamos.fecha_fin,prestamos.finalizado');
		$this->db->from('usuarios');
		$this->db->join('usuarios_prestamos','usuarios.id=usuarios_prestamos.usuarios_id');
		$this->db->join('prestamos','prestamos.id=usuarios_prestamos.prestamos_id');
		$this->db->join('ejemplares_prestamos','ejemplares_prestamos.prestamos_id=prestamos.id');
		$this->db->where('prestamos.id',$id);
		$query = $this->db->get();
		return $query->result_array();
	}
	public function get_cod_ejemplares(){
		$this->db->distinct();
		$this->db->select('cod_ejemplar');
		$query = $this->db->get('ejemplares');
		return $query->result_array();
	}
	public function set_cod_ejemplar(){
		$rand = rand(1,27);
		$letraRand = substr("ABCDEFGHIJKLMNOPQRSTUVWXYZ",-$rand,1);
		$numeroRand = rand(1,999999);
		$codigo = $numeroRand.''.$letraRand;
		return $codigo;
	}
	public function get_id_prestamo(){
		$this->db->select_max('id');
		$query = $this->db->get('prestamos');
		return $query->result_array();
	}
	public function add_historial($detalles){
		$datos = array
		(
			'detalles' => $detalles, 
		);
		$this->db->insert('historial',$datos);
	}
	public function add_administrador($usuario,$password,$usuarios_id){
		$datos = array(
			'usuario' => $usuario,
			'password' => $password,
			'usuarios_id' => $usuarios_id, 
			);
		$this->db->insert('administradores',$datos);
	}
	public function get_incidencias(){
		$query = $this->db->get('incidencias');
		return $query->result_array();
	}

	public function get_incidencia($asunto){
		$this->db->where('asunto',$asunto);
		$query = $this->db->get('incidencias');
		return $query->result_array();
	}

	public function delete_historial(){
		$this->db->empty_table('historial');
	}

	public function get_numero_prestamos($user_id){
		$this->db->from('usuarios_prestamos');
		$this->db->join('prestamos','prestamos.id=usuarios_prestamos.prestamos_id');
		$this->db->where('usuarios_prestamos.usuarios_id',$user_id);
		$this->db->where('finalizado',0);
		$query = $this->db->count_all_results();
		return $query;
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						Libros                  |
	*	|_______________________________________________|
	*/

	public function get_libro($dato,$tipoBusqueda){
		$this->db->where($tipoBusqueda,$dato);
		$query = $this->db->get('libros');
		return $query->result_array();
	}
	public function set_libro($isbn,$titulo,$autor,$paginas,$cdu,$fecha_p){
		$datosNuevos= array(
			'ISBN' => $isbn,
			'titulo' => $titulo,
			'autor' => $autor,
			'paginas' => $paginas,
			'cdu' => $cdu,
			'fecha_publicacion' => $fecha_p,
			);
		$this->db->where('ISBN',$isbn);
		$this->db->update('libros',$datosNuevos);
	}
	public function add_libro($isbn,$titulo,$autor,$paginas,$cdu,$fecha_p){
		$datos= array(
			'ISBN' => $isbn,
			'titulo' => $titulo,
			'autor' => $autor,
			'paginas' => $paginas,
			'cdu' => $cdu,
			'fecha_publicacion' => $fecha_p,
			);
		$this->db->insert('libros',$datos);
	}
	public function delete_libro($isbn){

		$this->db->delete('libros',array('ISBN'=>$isbn));
		$this->db->delete('ejemplares',array('libros_ISBN'=>$isbn));
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						Usuarios                |
	*	|_______________________________________________|
	*/

	public function add_user($dni,$nombre,$apellidos,$domicilio,$curso,$n_contacto,$correo){
		$datos= array(
			'id' => rand(1,999999),
			'dni' => $dni,
			'nombre' => $nombre,
			'apellidos' => $apellidos,
			'domicilio' => $domicilio,
			'curso' => $curso,
			'n_contacto' => $n_contacto,
			'correo' => $correo,
			);
		$this->db->insert('usuarios',$datos);
	}

	public function get_user($dato,$tipoBusqueda){
		$this->db->where($tipoBusqueda,$dato);
		$this->db->where('id != 0');
		$query = $this->db->get('usuarios');
		return $query->result_array();
	}

	public function set_user($dni,$nombre,$apellidos,$domicilio,$curso,$n_contacto,$correo){
		$datosNuevos= array(
			'nombre' => $nombre,
			'apellidos' => $apellidos,
			'domicilio' => $domicilio,
			'curso' => $curso,
			'n_contacto' => $n_contacto,
			'correo' => $correo,
			);
		$this->db->where('DNI',$dni);
		$this->db->update('usuarios',$datosNuevos);
	}
	public function delete_user($id){
		$this->db->delete('usuarios',array('id'=>$id));
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						Ejemplares              |
	*	|_______________________________________________|
	*/

	public function add_ejemplar($isbn,$cod_ejemplar,$estado){
		$datos= array(
			'libros_ISBN' => $isbn,
			'cod_ejemplar' => $cod_ejemplar,
			'estado' => $estado,
			);
		$this->db->insert('ejemplares',$datos);
	}
	public function get_ejemplar($cod_ejemplar){
		$this->db->where('cod_ejemplar',$cod_ejemplar);
		$this->db->join('libros','libros.ISBN=ejemplares.libros_ISBN');
		$query = $this->db->get('ejemplares');
		return $query->result_array();
	}

	public function set_ejemplar($cod_ejemplar,$isbn,$estado){
		$datosNuevos= array(
			'estado' => $estado,
			);
		$this->db->where('cod_ejemplar',$cod_ejemplar);
		$this->db->update('ejemplares',$datosNuevos);
	}
	public function delete_ejemplar($cod_ejemplar){
		$this->db->delete('ejemplares',array('cod_ejemplar'=>$cod_ejemplar));
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						Prestamos               |
	*	|_______________________________________________|
	*/

	public function add_prestamo($idEjemplar,$id_user,$cod_ejemplar,$fechaFin,$gratuito){
		$fechaActual = date('Y-m-d');
		if($gratuito == 1){
			$fechaFin = date('Y-6-21',strtotime('+1 years'));
		}
		$datosUsuario = array(
			'prestamos_id' => $idEjemplar,
			'usuarios_id' => (int)$id_user,
			);
		$datosEjemplar = array(
			'prestamos_id' => $idEjemplar,
			'ejemplares_cod_ejemplar' => $cod_ejemplar,
			'fecha_inicio' => $fechaActual,
			'fecha_fin' => $fechaFin,
			);
		$datosPrestamo = array(
			'id' => $idEjemplar,
			'finalizado' => 0,
			'gratuito' => 1,
		);
		$this->db->insert('prestamos',$datosPrestamo);
		$this->db->insert('usuarios_prestamos',$datosUsuario);
		$this->db->insert('ejemplares_prestamos',$datosEjemplar);
	}
	public function set_prestamo($id,$nuevaFecha,$finalizado){
		$datosPrestamo= array(
			'id' => $id,
			'finalizado' => $finalizado,
			);
		$datosEjemplar = array(
			'prestamos_id' => $id,
			'fecha_fin' => $nuevaFecha,
			);
		$this->db->where('id',$id);
		$this->db->update('prestamos',$datosPrestamo);

		$this->db->where('prestamos_id',$id);
		$this->db->update('ejemplares_prestamos',$datosEjemplar);
	}

	public function delete_prestamo($id){
		$this->db->delete('usuarios_prestamos',array('prestamos_id'=>$id));
		$this->db->delete('ejemplares_prestamos',array('prestamos_id'=>$id));
		$this->db->delete('prestamos',array('id'=>$id));
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						Prestamos               |
	*	|_______________________________________________|
	*/

	public function add_incidencia($asunto,$descripcion,$idPrestamo){
		$datosIncidencia = array(
			'asunto' => $asunto,
			'descripcion' => $descripcion,
			'prestamos_id' => $idPrestamo,
			);
		$this->db->insert('incidencias',$datosIncidencia);
	}

	public function delete_incidencia($asunto,$idPrestamo){
		$this->db->where('asunto',$asunto);
		$this->db->where('prestamos_id',$idPrestamo);
		$this->db->delete('incidencias');
	}

}

?>