<?php

class biblioteca extends CI_controller{
	public function __construct(){
		parent::__construct();
		$this->load->library('form_validation');
		$this->load->model('biblioteca_model');
		$this->load->helper('url_helper');
		$this->load->helper('url');
		$this->load->helper('form');
		$this->load->helper('html');
	}

	public function login(){
		$data['title'] = 'Login';

		if(!$this->input->post('entrar')){
			$this->load->view('biblioteca/login',$data);
			$this->load->view('templates/footer',$data);
		}

		if($this->input->post('entrar')){
			$this->form_validation->set_rules('usuario','usuario','required');
			$this->form_validation->set_rules('password','password','required');
			$usuario = $this->input->post('usuario');
			$password = $this->input->post('password');
			$comprobacion = $this->biblioteca_model->comprobarUser($usuario,$password);

			if($this->form_validation->run()===FALSE || empty($comprobacion)){
				$this->load->view('biblioteca/login',$data);
				$this->load->view('templates/footer',$data);
			}	
			else{
				$data['title'] = 'Listado de libros';
				$data['libros'] = $this->biblioteca_model->get_biblioteca();
				$this->load->view('templates/headerAdmin',$data);
				$this->load->view('biblioteca/index',$data);
				$this->load->view('templates/footerAdmin',$data);
			}
		}	
	}

	public function busqueda(){
		$data['title'] = 'Busqueda';
		$data['usuarios'] = $this->biblioteca_model->get_usuarios(); 
		if($this->input->post('usuarios')){
			$data['busqueda'] = 'usuarios';
		}
		if($this->input->post('libros')){
			$data['busqueda'] = 'libros';
		}
		if($this->input->post('ejemplares')){
			$data['busqueda'] = 'ejemplares';
		}
		if($this->input->post('prestamos')){
			$data['busqueda'] = 'prestamos';
		}
		if($this->input->post('buscarUsuarios')){
			$dni = $this->input->post('DNI');
			$nombre = $this->input->post('nombre');
			$apellidos = $this->input->post('apellidos');
			$domicilio = $this->input->post('domiclio');
			$curso = $this->input->post('curso');
			$n_contacto = $this->input->post('n_contacto');
			$correo = $this->input->post('correo');
			$data['busquedaUsuarios'] = $this->biblioteca_model->buscar_usuarios($dni,$nombre,$apellidos,$domicilio,$curso,$n_contacto,$correo);
		}
		if($this->input->post('buscarLibros')){
			$isbn = $this->input->post('isbn');
			$titulo = $this->input->post('titulo');
			$autor = $this->input->post('autor');
			$paginas = $this->input->post('paginas');
			$cdu = $this->input->post('cdu');
			$fecha = $this->input->post('fecha_p');
			$data['busquedaLibros'] = $this->biblioteca_model->buscar_libros($isbn,$titulo,$autor,$paginas,$cdu,$fecha);
		}
		if($this->input->post('buscarEjemplares')){
			$cod_ejemplar = $this->input->post('cod_ejemplar');
			$isbn = $this->input->post('isbn');
			$titulo = $this->input->post('titulo');
			$estado = $this->input->post('estado');
			$data['busquedaEjemplares'] = $this->biblioteca_model->buscar_ejemplares($cod_ejemplar,$isbn,$titulo,$estado);
		}
		if($this->input->post('buscarPrestamos')){
			$nombreUsuario = $this->input->post('nombreUsuario');
			$apellidosUsuario = $this->input->post('apellidosUsuario');
			$codigoEjemplar = $this->input->post('codigoEjemplar');
			$fechaInicio = $this->input->post('fechaInicio');
			$fechaFin = $this->input->post('fechaFin');
			$fechaI = date('Y-m-d', strtotime($fechaInicio));
			$fechaF = date('Y-m-d', strtotime($fechaFin));
			$data['busquedaPrestamos'] = $this->biblioteca_model->buscar_prestamos($nombreUsuario,$apellidosUsuario,$codigoEjemplar,$fechaInicio,$fechaFin);
		}
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/busqueda',$data);
		$this->load->view('templates/footerAdmin',$data);
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						Administrador           |
	*	|_______________________________________________|
	*/

		public function crearAdmin(){
		$data['title'] = 'Añadir administradores';
		$data['usuarios'] = $this->biblioteca_model->get_usuarios(); 
		if($this->input->post('crearAdmin')){
			$usuario = $this->input->post('usuario');
			$password = $this->input->post('password');
			$passwordB = $this->input->post('passwordB');
			$usuarios_id = $this->input->post('usuarios_id');
			//En caso de no ser iguales ambas contraseñas
			if($password != $passwordB){
				$this->biblioteca_model->get_usuarios();
				$this->load->view('templates/headerAdmin',$data);
				$this->load->view('biblioteca/indexUsuarios',$data);
				$this->load->view('templates/footerAdmin',$data);
				return;
			}
			$this->biblioteca_model->add_administrador($usuario,$password,$usuarios_id);
			$this->biblioteca_model->add_historial('Añadido admin cuyo ID de usuario es: <b>'.$usuarios_id.'</b>');
			$data['usuarios'] = $this->biblioteca_model->get_usuarios(); 	
			$data['title'] = 'Lista de usuarios';	
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/indexUsuarios',$data);
			$this->load->view('templates/footerAdmin',$data);
			return;
		}
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/crearAdmin',$data);
		$this->load->view('templates/footerAdmin',$data);

	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						historial                |
	*	|_______________________________________________|
	*/

	public function Historial(){
		$data['historial'] = $this->biblioteca_model->get_historial(); 
		$data['title'] = 'Historial';

		if($this->input->post('eliminarHistorial')){
			$this->biblioteca_model->delete_historial();
			$data['historial'] = $this->biblioteca_model->get_historial(); 
		}
		
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/historial',$data);
		$this->load->view('templates/footerAdmin',$data);
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						Libros                  |
	*	|_______________________________________________|
	*/


	//Funcion de la pestaña de la lista de libros
	public function index(){
		$data['title'] = 'Listado de libros';
		$data['libros'] = $this->biblioteca_model->get_biblioteca(); 
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/index',$data);
			$this->load->view('templates/footerAdmin',$data);
	}

	//Funcion de la pestaña crear libro
	public function crearLibro(){
		$data['title'] = 'Añadir libros';
		$data['libros'] = $this->biblioteca_model->get_biblioteca(); 


		if($this->input->post('crearLibro')){
			$isbn = $this->input->post('isbn');
			$titulo = $this->input->post('titulo');
			$autor = $this->input->post('autor');
			$paginas = $this->input->post('paginas');
			$cdu = $this->input->post('cdu');
			$fecha = $this->input->post('fecha_p');
			$data['isbn'] = $isbn;
			if($this->biblioteca_model->get_libro($isbn,'isbn')){
				$data['aviso'] = '<h4>Ya existe un libro con el isbn: '.$isbn.'. El libro no se ha podido introducir</h4>';
				$this->load->view('templates/headerAdmin',$data);
				$this->load->view('biblioteca/crearLibro',$data);
				$this->load->view('templates/footerAdmin',$data);
				return;
			}
			$this->biblioteca_model->add_libro($isbn,$titulo,$autor,$paginas,$cdu,$fecha);
			$this->biblioteca_model->add_historial('Añadido libro con ISBN: <b>'.$isbn.'</b>');
		}
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/crearLibro',$data);
		$this->load->view('templates/footerAdmin',$data);

	}
	//Funcion de la pestaña de editar libro
	public function editarLibro(){
		$data['title'] = 'Editar libros';
		if($this->input->post('buscar')){
			$dato = $this->input->post('dato');
			$tipoBusqueda = $this->input->post('tipo');
			$data['libro'] = $this->biblioteca_model->get_libro($dato,$tipoBusqueda);
		}
		//Si se guardan los datos
		if($this->input->post('editar')){
			$isbn = $this->input->post('isbn');
			$nuevoTitulo = $this->input->post('titulo');
			$nuevoAutor = $this->input->post('autor');
			$nuevoPaginas = $this->input->post('paginas');
			$nuevocdu = $this->input->post('cdu');
			$nuevoFecha = $this->input->post('fecha_p');
			$data['title'] = 'Libros';
			$this->biblioteca_model->set_libro($isbn,$nuevoTitulo,$nuevoAutor,$nuevoPaginas,$nuevocdu,$nuevoFecha);
			$this->biblioteca_model->add_historial('Editado el libro cuyo ISBN es: <b>'.$isbn.'</b>');
			$data['libros'] = $this->biblioteca_model->get_biblioteca(); 
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/index',$data);
			$this->load->view('templates/footerAdmin',$data);
		}
		else{
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/editarLibro',$data);
			$this->load->view('templates/footerAdmin',$data);	
		}	
	}	
	//Funcion de la pestaña eliminar libro
	public function eliminarLibro(){
		$data['title'] = 'Eliminar libros';
		if($this->input->post('buscar')){
			$dato = $this->input->post('dato');
			$tipoBusqueda = $this->input->post('tipo');
			$data['libro'] = $this->biblioteca_model->get_libro($dato,$tipoBusqueda);
		}	
		//Si se elimina el libro
		if($this->input->post('eliminar')){
			$isbn = $this->input->post('isbn');
			$this->biblioteca_model->add_historial('Eliminado libro y, con ello ejemplares con isbn: <b>'.$isbn.'</b>');
			$this->biblioteca_model->delete_libro($isbn);
		}
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/eliminarLibro',$data);
		$this->load->view('templates/footerAdmin',$data);	
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						usuarios                |
	*	|_______________________________________________|
	*/

	public function indexUsuarios(){
		$data['usuarios'] = $this->biblioteca_model->get_usuarios();
		$data['title'] = "Lista de usuarios";

		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/indexUsuarios',$data);
		$this->load->view('templates/footerAdmin',$data);
	}

	public function crearUsuario(){
		$data['title'] = "Añadir usuario";
		if($this->input->post('crearUsuario')){
			$dni = $this->input->post('DNI');
			$nombre = $this->input->post('nombre');
			$apellidos = $this->input->post('apellidos');
			$domicilio = $this->input->post('domicilio');
			$curso = $this->input->post('curso');
			$n_contacto = $this->input->post('n_contacto');
			$correo = $this->input->post('correo');
			if($this->biblioteca_model->get_user($dni,'DNI')){
				$data['aviso'] = '<h4> Ya existe un usuario con el DNI: '.$dni.'. El usuario no se ha podido introducir.</h4>';
				$this->load->view('templates/headerAdmin',$data);
				$this->load->view('biblioteca/crearUsuario',$data);
				$this->load->view('templates/footerAdmin',$data);
				return;
			}
			$this->biblioteca_model->add_user($dni,$nombre,$apellidos,$domicilio,$curso,$n_contacto,$correo);
			$this->biblioteca_model->add_historial('Creado el usuario cuyo dni es: <b>'.$dni.'</b>');
		}
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/crearUsuario',$data);
		$this->load->view('templates/footerAdmin',$data);
	}
	public function editarUsuario(){
		$data['title'] = 'Editar usuarios';
		if($this->input->post('buscar')){
			$dato = $this->input->post('dato');
			$tipoBusqueda = $this->input->post('tipo');
			$data['usuario'] = $this->biblioteca_model->get_user($dato,$tipoBusqueda);
		}
		//Si se guardan los datos
		if($this->input->post('editar')){
			$dni = $this->input->post('dni');
			$nuevoNombre = $this->input->post('nombre');
			$nuevoApellidos = $this->input->post('apellidos');
			$nuevoDomicilio = $this->input->post('domicilio');
			$nuevoCurso = $this->input->post('curso');
			$nuevoContacto = $this->input->post('n_contacto');
			$nuevoCorreo = $this->input->post('correo');
			$this->biblioteca_model->add_historial('Editado el usuario cuyo dni es: <b>'.$dni.'</b>');
			$this->biblioteca_model->set_user($dni,$nuevoNombre,$nuevoApellidos,$nuevoDomicilio,$nuevoCurso,$nuevoContacto,$nuevoCorreo);
			$data['title'] = 'Lista de usuarios';
			$data['usuarios'] = $this->biblioteca_model->get_usuarios(); 
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/indexUsuarios',$data);
			$this->load->view('templates/footerAdmin',$data);
		}
		else{
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/editarUsuario',$data);
			$this->load->view('templates/footerAdmin',$data);	
		}	
	}

	public function eliminarUsuario(){
		$data['title'] = 'Eliminar usuarios';
		if($this->input->post('buscar')){
			$dato = $this->input->post('dato');
			$tipoBusqueda = $this->input->post('tipo');
			$data['usuario'] = $this->biblioteca_model->get_user($dato,$tipoBusqueda);;
		}	
		//Si se elimina los datos
		if($this->input->post('eliminar')){
			$id = $this->input->post('id');
			$dni = $this->input->post('dni');
			$this->biblioteca_model->add_historial('Eliminado el usuario con dni: <b>'.$dni.'</b>');
			$this->biblioteca_model->delete_user($id);
		}
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/eliminarUsuario',$data);
		$this->load->view('templates/footerAdmin',$data);	
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						ejemplares              |
	*	|_______________________________________________|
	*/

	public function indexEjemplares(){
		$data['ejemplares'] = $this->biblioteca_model->get_ejemplares();
		$data['title'] = "Lista de ejemplares";

		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/indexEjemplares',$data);
		$this->load->view('templates/footerAdmin',$data);
	}

	public function crearEjemplar(){
		$data['libros'] = $this->biblioteca_model->get_biblioteca();
		$data['title'] = "Crear ejemplares";

		if($this->input->post('crearEjemplar')){
			$isbn = $this->input->post('isbn');
			$estado = $this->input->post('estado');
			$cod_ejemplar = $this->biblioteca_model->set_cod_ejemplar();
			$this->biblioteca_model->add_ejemplar($isbn,$cod_ejemplar,$estado);
			$this->biblioteca_model->add_historial('Creado el ejemplar cuyo codigo/isbn es: <b>'.$cod_ejemplar.' / '.$isbn.'</b>');
		}
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/crearEjemplar',$data);
		$this->load->view('templates/footerAdmin',$data);
	}
	public function editarEjemplar(){
		$data['title'] = 'Editar ejemplares';
		$data['ejemplares'] = $this->biblioteca_model->get_cod_ejemplares();
		if($this->input->post('buscar')){
			$cod_ejemplar = $this->input->post('cod_ejemplar');
			$data['ejemplar'] = $this->biblioteca_model->get_ejemplar($cod_ejemplar);
		}
		//Si se guardan los datos
		if($this->input->post('editar')){
			$cod_ejemplar = $this->input->post('cod_ejemplar');
			$isbn = $this->input->post('isbn');
			$nuevoEstado = $this->input->post('estado');
			$data['title'] = 'Lista de ejemplares';
			$this->biblioteca_model->set_ejemplar($cod_ejemplar,$isbn,$nuevoEstado);
			$this->biblioteca_model->add_historial('Modificacion del ejemplar cuyo codigo es: <b>'.$cod_ejemplar.'</b>');
			$data['ejemplares'] = $this->biblioteca_model->get_ejemplares();
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/indexEjemplares',$data);
			$this->load->view('templates/footerAdmin',$data);
		}
		else{
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/editarEjemplar',$data);
			$this->load->view('templates/footerAdmin',$data);	
		}	
	}
	public function eliminarEjemplar(){
		$data['title'] = 'Eliminar ejemplares';
		if($this->input->post('buscar')){
			$cod_ejemplar = $this->input->post('cod_ejemplar');
			$data['ejemplar'] = $this->biblioteca_model->get_ejemplar($cod_ejemplar);
		}	
		//Si se elimina los datos
		if($this->input->post('eliminar')){
			$cod_ejemplar = $this->input->post('cod_ejemplar');
			$this->biblioteca_model->delete_ejemplar($cod_ejemplar);
			$this->biblioteca_model->add_historial('ejemplar cuyo codigo era: <b>'.$cod_ejemplar.'</b> fue eliminado');
		}
		$data['ejemplares'] = $this->biblioteca_model->get_cod_ejemplares();
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/eliminarEjemplar',$data);
		$this->load->view('templates/footerAdmin',$data);	
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						Prestamos	            |
	*	|_______________________________________________|
	*/

	public function crearPrestamo(){
		$data['ejemplares'] = $this->biblioteca_model->get_ejemplares();
		$data['usuarios'] = $this->biblioteca_model->get_usuarios();
		$data['title'] = "Crear prestamos";
		if($this->input->post('prestamoNormal')){
			$data['tipoPrestamo'] = 'normal';
		}
		if($this->input->post('prestamoGratuito')){
			$data['tipoPrestamo'] = 'gratuito';
		}
		if($this->input->post('datosEjemplar')){
			$cod_ejemplar = $this->input->post('cod_ejemplar');
			$data['ejemplar'] = $this->biblioteca_model->get_ejemplar($cod_ejemplar);
		}
		if($this->input->post('crearPrestamo')){
			$cod_ejemplar = $this->input->post('cod_ejemplar');
			$user_id = $this->input->post('id_usuario');
			$fechaFin = $this->input->post('fechaFin');
			$tipo = $this->input->post('tipo');
			$idPrestamo = $this->biblioteca_model->get_id_prestamo();
				/*
				*
				*Comprueba que el ejemplar del prestamo insertado no está en uso actualmente
				*
				*/
				$ejemplarEnUso = $this->biblioteca_model->get_prestamos('noFinalizado');
				foreach ($ejemplarEnUso as $ejemplarEnUso_value):
					$uso = $ejemplarEnUso_value['ejemplares_cod_ejemplar'];
				if($uso == $cod_ejemplar){
					$usado = 1;
				}
				endforeach;
				if(isset($usado) && $usado == 1){
					$data['mensaje'] = 'El ejemplar con codigo <b>' .$cod_ejemplar. '</b> ya está prestado';
					$this->load->view('templates/headerAdmin',$data);
					$this->load->view('biblioteca/crearPrestamo',$data);
					$this->load->view('templates/footerAdmin',$data);
					return;
				}
			if($tipo == 'normal'){
				$max = $this->biblioteca_model->get_numero_prestamos($user_id);
				/*FIN*/
				if($max == 4){
					$data['mensaje'] = 'El numero maximo de prestamos por usuario es 4, El usuario cuyo ID es '.$user_id.' no puede realizar mas prestamos hasta que finalize alguno';
					$this->load->view('templates/headerAdmin',$data);
					$this->load->view('biblioteca/crearPrestamo',$data);
					$this->load->view('templates/footerAdmin',$data);
					return;
				}
				foreach ($idPrestamo as $idPrestamo_value):
					$numero = $idPrestamo_value['id']+1;
				$this->biblioteca_model->add_prestamo($numero,$user_id,$cod_ejemplar,$fechaFin,0);
				$this->biblioteca_model->add_historial('Se ha añadido el prestamo de tipo <b>'.$tipo.'</b> con el codigo del ejemplar/usuario: <b>'.$cod_ejemplar.'/'.$user_id.'</b>');
				endforeach;
			}
			if($tipo == 'gratuito'){
				foreach ($idPrestamo as $idPrestamo_value):
					$numero = $idPrestamo_value['id']+1;
				$this->biblioteca_model->add_prestamo($numero,$user_id,$cod_ejemplar,$fechaFin,1);
				$this->biblioteca_model->add_historial('Se ha añadido el prestamo de tipo <b>'.$tipo.'</b> con el codigo del ejemplar/usuario: <b>'.$cod_ejemplar.'/'.$user_id.'</b>');
				endforeach;
			}
		}
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/crearPrestamo',$data);
		$this->load->view('templates/footerAdmin',$data);
	}

	public function indexPrestamos(){
		$data['title'] = 'Lista de prestamos activos';
		if($this->input->post('gratuitos')){
			$data['title'] = 'Lista de prestamos gratuitos';
			$data['prestamos'] = $this->biblioteca_model->get_prestamos('gratuitos');
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/indexPrestamos',$data);
			$this->load->view('templates/footerAdmin',$data);
		}
		else if($this->input->post('todos')){
			$data['title'] = 'Todos los prestamos';
			$data['prestamos'] = $this->biblioteca_model->get_prestamos('todos');
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/indexPrestamos',$data);
			$this->load->view('templates/footerAdmin',$data);
		}
		else if($this->input->post('terminados')){
			$data['title'] = 'Prestamos finalizados';
			$data['prestamos'] = $this->biblioteca_model->get_prestamos('finalizado');
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/indexPrestamos',$data);
			$this->load->view('templates/footerAdmin',$data);
		}
		else{
			$data['title'] = 'Lista de prestamos activos';
			$data['prestamos'] = $this->biblioteca_model->get_prestamos('activos');
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/indexPrestamos',$data);
			$this->load->view('templates/footerAdmin',$data);
		}

	}
	public function editarPrestamo(){
		$data['title'] = 'Editar prestamos';
		$data['prestamos'] = $this->biblioteca_model->get_prestamos('todos');
		if($this->input->post('buscar')){
			$id = $this->input->post('dato');
			$data['prestamo'] = $this->biblioteca_model->get_prestamo($id);
		}
		//Si se guardan los datos
		if($this->input->post('editar')){
			$id = $this->input->post('id');
			$nuevaFecha = $this->input->post('fechaFin');
			$finalizado = $this->input->post('finalizado');
			if(!empty($finalizado)){
				$fin = 1;
			}
			else{
				$fin = 0;
			}
			$this->biblioteca_model->set_prestamo($id,$nuevaFecha,$finalizado);
			$this->biblioteca_model->add_historial('Modificacion del prestamo cuyo id es: <b>'.$id.'</b>');
			$data['prestamos'] = $this->biblioteca_model->get_prestamos('todos');
			$data['title'] = 'Lista de prestamos activos';
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/indexPrestamos',$data);
			$this->load->view('templates/footerAdmin',$data);
		}
		else{
			$this->load->view('templates/headerAdmin',$data);
			$this->load->view('biblioteca/editarPrestamo',$data);
			$this->load->view('templates/footerAdmin',$data);	
		}	
	}

	public function eliminarPrestamo(){
		$data['title'] = 'Eliminar prestamos';
		if($this->input->post('buscar')){
			$id = $this->input->post('dato');
			$data['prestamo'] = $this->biblioteca_model->get_prestamo($id);
		}	
		//Si se elimina los datos
		if($this->input->post('eliminar')){
			$id = $this->input->post('id');
			$this->biblioteca_model->delete_prestamo($id);
			$this->biblioteca_model->add_historial('prestamo cuyo ID era: <b>'.$id.'</b> fue eliminado');
		}
		$data['prestamos'] = $this->biblioteca_model->get_prestamos('todos');
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/eliminarPrestamo',$data);
		$this->load->view('templates/footerAdmin',$data);	
	}

	/*
	*	 ________________________________________________
	*	|												|
	*	|						Incidencias	            |
	*	|_______________________________________________|
	*/

	public function indexIncidencias(){
		$data['title'] = 'Lista de incidencias';

		$data['incidencias'] = $this->biblioteca_model->get_incidencias();
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/indexIncidencias',$data);
		$this->load->view('templates/footerAdmin',$data);
	}

	public function crearIncidencia(){
		$data['prestamos'] = $this->biblioteca_model->get_prestamos('todos');
		$data['title'] = "Abrir incidencia";

		if($this->input->post('crearIncidencia')){
			$asunto = $this->input->post('asunto');
			$descripcion = $this->input->post('descripcion');
			$idPrestamo = $this->input->post('idPrestamo');
			$this->biblioteca_model->add_incidencia($asunto,$descripcion,$idPrestamo);
			$this->biblioteca_model->add_historial('Creada la incidencia cuyo id del prestamo asociado/asunto es: <b>'.$idPrestamo.' / '.$asunto.'</b>');
		}
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/crearIncidencia',$data);
		$this->load->view('templates/footerAdmin',$data);
	}

	public function eliminarIncidencia(){
		$data['title'] = 'Eliminar incidencias';
		if($this->input->post('buscar')){
			$asunto = $this->input->post('dato');
			$data['incidencia'] = $this->biblioteca_model->get_incidencia($asunto);
		}	
		//Si se elimina los datos
		if($this->input->post('eliminar')){
			$asunto = $this->input->post('asunto');
			$idPrestamo = $this->input->post('prestamos_id');
			$this->biblioteca_model->delete_incidencia($asunto,$idPrestamo);
			$this->biblioteca_model->add_historial('incidencia cuyo Id del prestamo/asunto eran: <b>'.$idPrestamo.' / '.$asunto.'</b> fue eliminada');
		}
		$data['incidencias'] = $this->biblioteca_model->get_incidencias();
		$this->load->view('templates/headerAdmin',$data);
		$this->load->view('biblioteca/eliminarIncidencia',$data);
		$this->load->view('templates/footerAdmin',$data);	
	}
}

?>