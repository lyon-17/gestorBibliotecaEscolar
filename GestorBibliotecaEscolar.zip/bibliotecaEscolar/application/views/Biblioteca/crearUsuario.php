
<?php
$this->load->helper('form');
echo validation_errors();

$submit = array(
	'name' => 'crearUsuario',
	'value' => 'añadir usuario',
	'style' => 'border-radius:5px; margin: 5px;',
	);
echo 
 	'<div class="container-fluid">'.
		form_open('biblioteca/crearUsuario').
			'<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos del usuario</h3></div>
				<div class="panel-body">';
				if(isset($aviso)){
					echo $aviso;
				}
				echo '
					<div class="form-group">
						<label>DNI</label>
						<input type="text" class="form-control" name="DNI" placeholder="DNI" maxlength="9" minlength="9" required>
					</div>
					<div class="form-group">
						<label>Nombre</label>
						<input type="text" class="form-control" name="nombre" maxlength="120" placeholder="nombre" required>
					</div>
					<div class="form-group">
						<label>Apellidos</label>
						<input type="text" class="form-control" name="apellidos" maxlength="120" placeholder="apellidos" required>
					</div>
					<div class="form-group">
						<label>Domicilio</label>
						<input type="text" class="form-control" name="domicilio" maxlength="255" placeholder="domicilio" required>
					</div>
					<div class="form-group">
						<label>Curso</label>
						<input type="text" class="form-control" name="curso" maxlength="120" placeholder="curso" required>
					</div>
					<div class="form-group">
						<label>numero de contacto</label>
						<input type="number" class="form-control" name="n_contacto" maxlength="11" placeholder="XXX YY YY YY" required>
					</div>
					<div class="form-group">
						<label>correo</label>
						<input type="email" class="form-control" name="correo" maxlength="120" placeholder="example@test.com" required>
					</div>
				</div>'.form_submit($submit).'
			</div>
	</div>';
?>