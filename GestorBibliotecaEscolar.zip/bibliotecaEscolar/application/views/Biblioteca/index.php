
<?php

	echo '<br/>
			<div class="panel panel-default">
				<div class="panel-heading"><h3>'.$title.'</h3></div>
				<div class="panel-body">
					<table class="table">
						<tr>
							<th>ISBN</th>
							<th>Titulo</th>
							<th>Autor</th>
							<th>paginas</th>
							<th>CDU</th>
							<th>año publicacion</th>
						</tr>';
						foreach ($libros as $libros_item):
						echo'<tr>
								<td>' . $libros_item['ISBN'].'</td>
								<td>' . $libros_item['titulo'] . '</td>
								<td>' . $libros_item['autor'] . '</td>
								<td>' . $libros_item['paginas'] . '</td>
								<td>' . $libros_item['CDU'] . '</td>
								<td>' . $libros_item['fecha_publicacion'] . '</td>
							</tr>';
						endforeach;
		echo '		</table>
				</div>
			</div>';
	?>