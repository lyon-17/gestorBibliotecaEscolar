
<?php
$this->load->helper('form');
echo validation_errors();
$submit = array(
	'name' => 'crearPrestamo',
	'value' => 'crear el prestamo',
);
$atributtes = array(
	'class' => 'form-inline'
);
$submitUsuario = array(
	'name' =>'datosUsuario',
	'value' => 'Buscar datos',
	'class' => 'form-control',
	 );
$submitEjemplar = array(
	'name' =>'datosEjemplar',
	'value' => 'Buscar datos',
	'class' => 'form-control',
	 );
$submitPrestamo = array(
	'name' =>  'crearPrestamo',
	'value' => 'Crear prestamo',
	'class' => 'form-control',
	 );
$normal = array(
	'name' =>  'prestamoNormal',
	'value' => 'prestamo normal',
	'class' => 'form-control',
	);
$gratuito = array(
	'name' =>  'prestamoGratuito',
	'value' => 'prestamo gratuito',
	'class' => 'form-control',
	);
$hiddenNormal = array(
	'tipo' => 'normal', 
	);
$hiddenGratuito = array(
	'tipo' => 'gratuito', 
	);
$fechaFinGratuito = array(
	'fechaFin' => date('d/m/Y',strtotime('+1 years')),
	);
echo '<div class="container-fluid"><h3 style="color:white;">¿Que tipo de prestamo quieres crear?</h3>'.
		form_open('biblioteca/crearPrestamo',$atributtes).form_submit($normal).form_submit($gratuito).'
	</form><br/>';
	if(!isset($tipoPrestamo) || $tipoPrestamo=='normal'){
		   echo '<div class="panel panel-default">
					<div class="panel-heading"><h3>Añadir prestamo normal</h3></div>';
					if(isset($mensaje)){
						echo "<h4>".$mensaje.'</h4>';
					}
		   		echo form_open('biblioteca/crearPrestamo',$atributtes).form_hidden($hiddenNormal).
						'<div class="panel-body">
							<h4>Nombre del usuario</h4>
							<select class="form-control" name="id_usuario">';
								foreach ($usuarios as $usuarios_item):
									$id = $usuarios_item['id'];
									$nombre = $usuarios_item['nombre'];
									$apellidos = $usuarios_item['apellidos'];
									echo '<option value="'.$id.'">'.$nombre.' '.$apellidos.'</option>';
								endforeach;
				 	 echo '</select>
						<h4>Codigo del ejemplar</h4>
						<select class="form-control" name="cod_ejemplar">';
							foreach ($ejemplares as $ejemplares_item):
								$cod_e = $ejemplares_item['cod_ejemplar'];
								echo '<option value="'.$cod_e.'">'.$cod_e.'</option>';
							endforeach;
			  echo 		'</select><br/>
			  <h4>Fecha de finalizacion</h4>
			  <input class="form-control" type="date" name="fechaFin">
			  <br/><br/>'.
				 		form_submit($submitPrestamo).'
					</div>
				</div>
			</div></form>';
		}
	else if($tipoPrestamo=='gratuito'){
		   echo '<div class="panel panel-default">'.
		   			form_open('biblioteca/crearPrestamo',$atributtes).form_hidden($hiddenGratuito).'
				<div class="panel-heading"><h3>Añadir prestamo gratuito</h3></div>
					<div class="panel-body">
					<h4>id del usuario</h4>
					<select class="form-control" name="id_usuario">';
								foreach ($usuarios as $usuarios_item):
									$id = $usuarios_item['id'];
									$nombre = $usuarios_item['nombre'];
									$apellidos = $usuarios_item['apellidos'];
									echo '<option value="'.$id.'">'.$nombre.' '.$apellidos.'</option>';
								endforeach;
				 	 echo '</select>
					<h4>codigo del ejemplar</h4>
						<select class="form-control" name="cod_ejemplar">';
							foreach ($ejemplares as $ejemplares_item):
								$cod_e = $ejemplares_item['cod_ejemplar'];
								echo '<option value="'.$cod_e.'">'.$cod_e.'</option>';
							endforeach;
			  echo 		'</select><br/>
			  <h4>Fecha de finalizacion</h4>
			  <input class="form-control" type="date" disabled>'.form_hidden($fechaFinGratuito).'
			  <br/><br/>'.
				 		form_submit($submitPrestamo).'
					</div>
				</div>
			</div></form>';
		}
	/*
	*Parte de buscar ejemplar
	*/
		echo form_open('biblioteca/crearPrestamo',$atributtes).
     '<div class="panel panel-default">
		<div class="panel-heading"><h3>Buscar datos del ejemplar</h3></div>
				<div class="panel-body">
					<label>Escoja el codigo del ejemplar </label><select class="form-control" name="cod_ejemplar">';
						foreach ($ejemplares as $ejemplares_item):
							$cod_e = $ejemplares_item['cod_ejemplar'];
							echo '<option value="'.$cod_e.'">'.$cod_e.'</option>';
						endforeach;
		  echo 		'</select>'.
				'<br/><br/>'.form_submit($submitEjemplar).'
				</div>
		</div>';
echo '</div>';
		if(!empty($ejemplar)){
			echo '<div class="panel panel-default">
					<div class="panel-heading"><h3>Información del ejemplar</h3></div>
					<div class="panel-body">';
					  	foreach ($ejemplar as $ejemplar_item):
					  		echo
					  		'<div class="form-group">
					  		<table class="table table-striped table-hover table-condesed">
					  			<tr>
					  				<th>Codigo del ejemplar</th>
					  				<th>Titulo</th>
					  				<th>Estado</th>
					  			</tr>
					  			<tr>
					  				<td>'.$ejemplar_item['cod_ejemplar'].'</td>
					  				<td>'.$ejemplar_item['titulo'].'</td>
					  				<td>'.$ejemplar_item['estado'].'</td>
					  			</tr>
					  		</table>';
					  	endforeach;
			echo 	'</div>
				</div>
			</div>';
		}
?>