<?php

echo validation_errors();

$attributes = array(
	'class' => 'form-inline',
	);
echo '<div class="container-fluid">';
echo form_open('biblioteca/eliminarPrestamo',$attributes);
	echo '<br/><h3>Busqueda</h3>
		<b>Indica el id que quieras eliminar</b><br/>
		<div class="form-group">
			<input class="form-control" name="dato" type="text" value="">
		</div>
	<input class="btn btn-default" type="submit" name="buscar" value="ver prestamo"></form><br/>';

if(!empty($prestamo)){
	echo form_open('biblioteca/eliminarPrestamo');

	foreach ($prestamo as $prestamo_item):
		$id = $prestamo_item['id_prestamo'];
		$nombre = $prestamo_item['nombre'];
		$apellidos = $prestamo_item['apellidos'];
		$cod_ejemplar = $prestamo_item['ejemplares_cod_ejemplar'];
		$fechaFin = $prestamo_item['fecha_fin'];
		$finalizado = $prestamo_item['finalizado'];
		$hidden = array('id' => $id);
		echo form_hidden($hidden).
		'	<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos del prestamo</h3></div>
				<div class="panel-body">';
				if($finalizado==0){
				echo '<h3>Atencion, este prestamo no ha finalizado</h3>';
				}
			   echo '<div class="form-group">
						<label>ID del prestamo</label>
						<input type="name" name="id" class="form-control" value="'.$id.'" disabled>
					</div>
					<div class="form-group">
						<label>Nombre</label>
						<input type="name" name="nombre" class="form-control" value="'.$nombre.'" disabled>
					</div>
					<div class="form-group">
						<label>Apellidos</label>
						<input type="name" name="apellidos" class="form-control" value="'.$apellidos.'" disabled>
					</div>
					<div class="form-group">
						<label>Codigo del ejemplar</label>
						<input type="name" name="cod_ejemplar" class="form-control" value="'.$cod_ejemplar.'" disabled>
					</div>';
					if($finalizado == 1){
						$finalizado = 1;
			  echo '<div class="form-group">
						<label>Fecha de finalizacion</label>
						<input type="text" name="fechaFin" class="form-control" value="Sin fecha" disabled>
					</div>';
					}
					else{
						$finalizado = 0;
			  echo '<div class="form-group">
						<label>Fecha de finalizacion</label>
						<input type="date" name="fechaFin" class="form-control" value="'.$fechaFin.'" disabled>
					</div>';		
					}
				'</div>
			</div>';
	endforeach;
		if(!empty($prestamo)){
			echo '<br/><b>estas seguro que quieres eliminar este prestamo</b><input type="submit" name="eliminar" value="Si">&nbsp;<input type="submit" name="salir" value="No">';
		}
	}
	echo '</div>
	</div>';

?>