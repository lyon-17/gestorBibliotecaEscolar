
<?php
$this->load->helper('form');
echo validation_errors();

$submit = array(
	'name' => 'crearIncidencia',
	'value' => 'abrir incidencia',
	'class' => 'form-control',
);
$atributtes = array(
	'class' => 'form-inline'
);
echo '<div class="container-fluid">'.
		form_open('biblioteca/crearIncidencia',$atributtes).
			'<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos de la incidencia</h3></div>
				<div class="panel-body">
				<label>id del prestamo</label>
				<select class="form-control" name="idPrestamo">';
					foreach ($prestamos as $prestamos_item):
						$prestamosId = $prestamos_item['id_prestamo'];
						echo '<option value="'.$prestamosId.'">'.$prestamosId.'</option>';
					endforeach;
		  echo '</select>
				<div class="form-group">
					<label>asunto</label>
					<input type="name" name="asunto" maxlength="120" class="form-control" value="">
				</div>
				<div class="form-group">
					<label>descripcion</label>
					<textarea name="descripcion" style="resize:none;" class="form-control" rows="5" cols="60" maxlength="250" value=""></textarea>
				</div>
			</div>'.
			form_submit($submit);
	echo '</div>';

?>