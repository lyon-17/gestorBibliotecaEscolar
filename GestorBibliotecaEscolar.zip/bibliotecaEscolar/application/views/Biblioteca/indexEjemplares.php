
<?php
$this->load->helper('form');
echo validation_errors();

echo '<br/>
			<div class="panel panel-default">
			<div class="panel-heading"><h3>'.$title.'</h3></div>
				<div class="panel-body">
					<table class="table table-striped table-hover table-condesed">
						<tr>
							<th>Codigo del ejemplar</th>
							<th>ISBN</th>
							<th>Titulo</th>
							<th>Estado</th>
						</tr>';
					foreach ($ejemplares as $ejemplares_item):
					echo'<tr>
							<td>' . $ejemplares_item['cod_ejemplar'].'</td>
							<td>' . $ejemplares_item['libros_ISBN'].'</td>
							<td>' . $ejemplares_item['titulo'] . '</td>
							<td>' . $ejemplares_item['estado'] . '</td>
						</tr>';
					endforeach;
	echo '			</table>
				</div>
			</div>';
	?>