
<?php
$this->load->helper('form');
echo validation_errors();
$eliminar = array(
	'name' => 'eliminarHistorial',
	'value' => 'Limpiar el historial',
	'class' => 'form-control',
	);
$atrr = array(
	'class' => 'form-inline',
	);
		echo '<br/>
		<div class="panel panel-default">
			<div class="panel-heading">
			<h4>Historial</h4>
			</div>
			<div class="panel-body">
			'.form_open('biblioteca/historial',$atrr).form_submit($eliminar).'
			<br/><br/>
			<table class="table table-condesed">
			<tr>
				<th>Fecha</th>
				<th>informacion</th>
			</tr>';
		foreach ($historial as $historial_item):
		echo'
				<td>' . $historial_item['fecha'].'</td>
				<td>' . $historial_item['detalles'] . '</td>
			</tr>';

		;
		endforeach;
	?>
</table>