<?php

echo validation_errors();

$attributes = array(
	'class' => 'form-inline',
	);

echo '<div class="container-fluid">';
echo form_open('biblioteca/eliminarLibro',$attributes);
	echo '<br/><h3>Busqueda</h3>
		<select class="form-control" name="tipo">
			<option value="titulo">titulo</option>
			<option value="ISBN">ISBN</option>
			<option value="autor">autor</option>
			<option value="CDU">CDU</option>
			<option value="fecha_publicacion">año</option>
		</select>
		<div class="form-group">
			<input class="form-control" name="dato" type="text" value=""><br/>
		</div>
	<input class="btn btn-default" type="submit" name="buscar" value="buscar libros"></form><br/>';

if(!empty($libro)){
	echo form_open('biblioteca/eliminarLibro');

	foreach ($libro as $libro_item):

	if(empty($isbn)){
		$isbn = $libro_item['ISBN'];
		$titulo = $libro_item['titulo'];
		$autor = $libro_item['autor'];
		$paginas = $libro_item['paginas'];
		$cdu = $libro_item['CDU'];
		$fecha_publicacion = $libro_item['fecha_publicacion'];
		$hidden = array('isbn' => $isbn);
		echo form_hidden($hidden).
		'	<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos del libro</h3></div>
				<div class="panel-body">
				<div class="form-group">
						<label>ISBN</label>
						<input type="name" class="form-control" value="'.$isbn.'" disabled>
					</div>
					<div class="form-group">
						<label>Titulo</label>
						<input type="name" class="form-control" value="'.$titulo.'"disabled>
					</div>
					<div class="form-group">
						<label>Autor</label>
						<input type="name" class="form-control" value="'.$autor.'"disabled>
					</div>
					<div class="form-group">
						<label>paginas</label>
						<input type="name" class="form-control" value="'.$paginas.'"disabled>
					</div>
					<div class="form-group">
						<label>CDU</label>
						<input type="name" class="form-control" value="'.$cdu.'"disabled>
					</div>
					<div class="form-group">
						<label>año de publicacion</label>
						<input type="name" class="form-control" value="'.$fecha_publicacion.'"disabled>
					</div>';
				if(!empty($libro)){
			echo '<br/><b>Estas seguro que quieres eliminar este libro</b>
				<input style="border-radius:5px; margin: 5px; padding:0px 10px;" type="submit" name="eliminar" value="Si">
				<input style="border-radius:5px; margin: 5px; padding:0px 10px;" type="submit" name="salir" value="No">';
		}
			echo '</div>
				</div>
			</div>';
	}
	endforeach;
	}

?>