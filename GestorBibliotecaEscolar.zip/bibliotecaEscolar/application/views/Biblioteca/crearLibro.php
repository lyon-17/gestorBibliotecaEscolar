
<?php
$this->load->helper('form');
echo validation_errors();

$submit = array(
	'name' => 'crearLibro',
	'value' => 'añadir libro',
	'style' => 'border-radius:5px; margin: 5px;',
 	);
echo 	'<div class="container-fluid">'.
	 		form_open('biblioteca/crearLibro').
			'<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos del libro</h3></div>
				<div class="panel-body">
				';
				if(isset($aviso)){
					echo $aviso;
				}
				echo '<div class="form-group">
						<label>ISBN</label>
						<input type="name" maxlength="120" name="isbn" class="form-control" required>
					</div>
					<div class="form-group">
						<label>Titulo</label>
						<input type="name" maxlength="255" name="titulo" class="form-control" required> 
					</div>
					<div class="form-group">
						<label>Autor</label>
						<input type="name" maxlength="120" name="autor" class="form-control" required>
					</div>
					<div class="form-group">
						<label>paginas</label>
						<input type="name" maxlength="11" name="paginas" class="form-control"> 
					</div>
					<div class="form-group">
						<label>CDU</label>
						<input type="name" maxlength="120" name="cdu" class="form-control">
					</div>
					<div class="form-group">
						<label>año de publicacion</label>
						<input type="number" maxlength="11" name="fecha_p" class="form-control">
					</div>
				</div>'.form_submit($submit).'
			</div>
		</div>';

?>