
<?php
$this->load->helper('form');
echo validation_errors();

$submit = array(
	'name' => 'crearEjemplar',
	'value' => 'añadir ejemplar',
	'style' => 'border-radius:5px; margin: 5px;',
);
$atributtes = array(
	'class' => 'form-inline'
);
echo '<div class="container-fluid">'.
		form_open('biblioteca/crearEjemplar',$atributtes).
			'<div class="panel panel-default">
				<div class="panel-heading"><h3>Datos del ejemplar</h3></div>
				<div class="panel-body">
				<label>Título del libro</label><select class="form-control" name="isbn">';
					foreach ($libros as $libros_item):
						$l_isbn = $libros_item['ISBN'];
						$titulo = $libros_item['titulo'];
						echo '<option value="'.$l_isbn.'">'.$titulo.'</option>';
					endforeach;
		  echo '</select>
				<div class="form-group">
					<label>Estado</label>
					<input type="name" name="estado" maxlength="120" class="form-control" value="'.$estado.'" required>
				</div>
			</div>'.
			form_submit($submit);
	echo '</div>';

?>