<?php

	echo '<br/>
			<div class="panel panel-default">
				<div class="panel-heading"><h3>'.$title.'</h3></div>
				<div class="panel-body">
				<br/><table class="table table-striped table-hover">
					<tr>
						<th>DNI</th>
						<th>Nombre</th>
						<th>Apellidos</th>
						<th>Domicilio</th>
						<th>Curso</th>
						<th>Numero de contacto</th>
						<th>Correo de contacto</th>
					</tr>';
					foreach ($usuarios as $usuarios_item):
					echo '<tr>
						   <td>' . $usuarios_item['DNI'] . '</td>'
						 .'<td>' . $usuarios_item['nombre'] . '</td>'
						 .'<td>' . $usuarios_item['apellidos'] . '</td>'
						 .'<td>' . $usuarios_item['domicilio'] . '</td>'
						 .'<td>' . $usuarios_item['curso'] . '</td>'
						 .'<td>' . $usuarios_item['n_contacto'] . '</td>'
						 .'<td>' . $usuarios_item['correo'] . '</td>
						 </tr>';
					endforeach;
		  echo '</table>
			</div>
		</div>';

?>