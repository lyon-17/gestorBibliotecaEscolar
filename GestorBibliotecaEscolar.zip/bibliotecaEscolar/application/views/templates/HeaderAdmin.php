<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="Content-Type" context="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <title>Biblioteca</title>

    <link href="<?php echo base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/css/font-awesome.min.css') ?>" rel="stylesheet">
</head>
<body style="background-size:100%, 100%; background-image: url(../../../images/fondo.jpg);">
<br/>
<br/>

	<div class="container-fluid">
	      <nav class="navbar navbar-inverse navbar-fixed-top">

          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse"  data-target="#bs-nav-navbar-collapse-1">
              <span class="sr-only">Toggle navigation</span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
              <span class="icon-bar"></span>
            </button>
            <a href="../Biblioteca/busqueda" class="navbar-brand">Búsqueda</a>  
          </div>

          <div class="collapse navbar-collapse" id="bs-nav-navbar-collapse-1">
          <!--Barra de navegacion-->
            <ul class="nav navbar-nav">
            <li><a href="../Biblioteca/historial">Historial</a></li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Usuarios</span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="../Biblioteca/indexUsuarios">Lista de usuarios</a></li>
                  <li><a href="../Biblioteca/crearUsuario">añadir usuarios</a></li>
                  <li><a href="../Biblioteca/editarUsuario">editar usuarios</a></li>
                  <li><a href="../Biblioteca/eliminarUsuario">eliminar usuarios</a></li>
                  <li><a href="../Biblioteca/crearAdmin">administradores</a></li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Libros</span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="../Biblioteca/index">Lista de libros</a></li>
                  <li><a href="../Biblioteca/crearLibro">Añadir libros</a></li>
                  <li><a href="../Biblioteca/editarLibro">Editar libros</a></li>
                  <li><a href="../Biblioteca/eliminarLibro">Eliminar libros</a></li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Ejemplares</span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="../Biblioteca/indexEjemplares">Lista de ejemplares</a></li>
                  <li><a href="../Biblioteca/crearEjemplar">Añadir ejemplares</a></li>
                  <li><a href="../Biblioteca/editarEjemplar">Editar ejemplares</a></li>
                  <li><a href="../Biblioteca/eliminarEjemplar">Eliminar ejemplares</a></li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Prestamos</span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="../Biblioteca/indexPrestamos">Lista de prestamos</a></li>
                  <li><a href="../Biblioteca/crearPrestamo">añadir prestamos</a></li>
                  <li><a href="../Biblioteca/editarPrestamo">editar prestamos</a></li>
                  <li><a href="../Biblioteca/eliminarPrestamo">eliminar prestamos</a></li>
                </ul>
              </li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Incidencias</span></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="../Biblioteca/indexIncidencias">Lista de incidencias</a></li>
                  <li><a href="../Biblioteca/crearIncidencia">Abrir incidencia</a></li>
                  <li><a href="../Biblioteca/eliminarIncidencia">Eliminar incidencias</a></li>
                </ul>
              </li>
            </ul>
            <!--Fin de la barra de navegacion-->
        </div>
      </nav>
