
<?php
$this->load->helper('form');
echo validation_errors();

$attributes = array(
	'class' => 'form-inline',
	);

	echo 
		form_open('biblioteca/busqueda',$attributes).
		'<br/><h3>¿Que quieres buscar?</h3>
		<input class="btn btn-default" type="submit" name="libros" value="libros">
		<input class="btn btn-default" type="submit" name="ejemplares" value="ejemplares">
		<input class="btn btn-default" type="submit" name="usuarios" value="usuarios">
		<input class="btn btn-default" type="submit" name="prestamos" value="prestamos">
		</form><br/>';
		if(isset($busquedaUsuarios)){
			echo '
			<div class="panel panel-default">
			
				<div class="panel-heading"><h3>Resultado de la busqueda:</h3></div>
				<div class="panel-body">
					<table class="table table-striped table-hover">
						<tr>
							<th>ID</th>
							<th>DNI</th>
							<th>Nombre</th>
							<th>Apellidos</th>
							<th>Domicilio</th>
							<th>Curso</th>
							<th>Numero de contacto</th>
							<th>Correo de contacto</th>
						</tr>';
						foreach ($busquedaUsuarios as $usuarios_item):
						echo '<tr>
							   <td>' . $usuarios_item['id'] . '</td>'
							 .'<td>' . $usuarios_item['DNI'] . '</td>'
							 .'<td>' . $usuarios_item['nombre'] . '</td>'
							 .'<td>' . $usuarios_item['apellidos'] . '</td>'
							 .'<td>' . $usuarios_item['domicilio'] . '</td>'
				 			 .'<td>' . $usuarios_item['curso'] . '</td>'
							 .'<td>' . $usuarios_item['n_contacto'] . '</td>'
							 .'<td>' . $usuarios_item['correo'] . '</td>
							 </tr>';
						endforeach;
					echo '
					</table>
				</div>
			</div>';
		}
		if(isset($busquedaLibros)){
			echo '
			<div class="panel panel-default">
				<div class="panel-heading"><h3>Resultado de la busqueda:</h3></div>
				<div class="panel-body">
					<table class="table table-striped table-hover">
						<tr>
							<th>ISBN</th>
							<th>Titulo</th>
							<th>Autor</th>
							<th>Paginas</th>
							<th>CDU</th>
							<th>Fecha de publicacion</th>
						</tr>';
						foreach ($busquedaLibros as $libros_item):
						echo '<tr>
							   <td>' . $libros_item['ISBN'] . '</td>'
							 .'<td>' . $libros_item['titulo'] . '</td>'
							 .'<td>' . $libros_item['autor'] . '</td>'
							 .'<td>' . $libros_item['paginas'] . '</td>'
							 .'<td>' . $libros_item['CDU'] . '</td>'
							 .'<td>' . $libros_item['fecha_publicacion'] . '</td>
							 </tr>';
						endforeach;
				echo '
					</table>
				</div>
			</div>';
		}
		if(isset($busquedaEjemplares)){
			echo '<br/>
			<div class="panel panel-default">
				<div class="panel-heading"><h3>Resultado de la busqueda:</h3></div>
				<div class="panel-body">
					<table class="table table-striped table-hover table-condesed">
						<tr>
							<th>Codigo del ejemplar</th>
							<th>ISBN</th>
							<th>Titulo</th>
							<th>Estado</th>
						</tr>';
					foreach ($busquedaEjemplares as $ejemplares_item):
					echo'<tr>
							<td>' . $ejemplares_item['cod_ejemplar'].'</td>
							<td>' . $ejemplares_item['libros_ISBN'].'</td>
							<td>' . $ejemplares_item['titulo'] . '</td>
							<td>' . $ejemplares_item['estado'] . '</td>
						</tr>';
					endforeach;
				echo '
					</table>
				</div>
			</div>';
		}
		if(isset($busquedaPrestamos)){
			echo '
			<div class="panel panel-default">
				<div class="panel-heading"><h3>Resultado de la busqueda:</h3></div>
				<div class="panel-body">
					<table class="table table-striped table-hover table-condesed">
						<tr>
							<th>Id del prestamo</th>
							<th>Nombre del usuario</th>
							<th>Apellidos del usuario</th>
							<th>Codigo del ejemplar</th>
							<th>Fecha de inicio</th>
							<th>Fecha de finalizacion</th>
						</tr>';
						foreach ($busquedaPrestamos as $prestamos_item):
						$fecha = date('d-m-Y', strtotime($prestamos_item['fecha_inicio']));
						$fechaFin = date('d-m-Y', strtotime($prestamos_item['fecha_fin']));
						if($fechaFin == '01-01-1970' || !$fechaFin){
							$fechaFin = 'Sin fecha';
						}
						echo '<tr>
								<td>' . $prestamos_item['id_prestamo'].'</td>
								<td>' . $prestamos_item['nombre'].'</td>
								<td>' . $prestamos_item['apellidos'].'</td>
								<td>' . $prestamos_item['ejemplares_cod_ejemplar'].'</td>
								<td>' . $fecha.'</td>
								<td>' . $fechaFin.'</td>';
						echo '</tr>';

						endforeach;
						echo '
					</table>
				</div>
			</div>';
		}
	if(isset($busqueda)){
		if($busqueda=='usuarios'){
			echo form_open('biblioteca/busqueda').
			'<div class="panel panel-default">
			<div class="panel-heading"><h3>Busqueda de usuarios</h3></div>
				<div class="panel-body">
					<div class="form-group">
						<label>DNI</label>
						<input type="text" class="form-control" name="DNI" dmaxlength="9">
					</div>
					<div class="form-group">
						<label>Nombre</label>
						<input type="text" class="form-control" name="nombre" maxlength="120">
					</div>
					<div class="form-group">
						<label>Apellidos</label>
						<input type="text" class="form-control" name="apellidos" maxlength="120">
					</div>
					<div class="form-group">
						<label>Domicilio</label>
						<input type="name" maxlength="255" class="form-control">
					</div>
					<div class="form-group">
						<label>Curso</label>
						<input type="name" maxlength="120" class="form-control">
					</div>
					<div class="form-group">
						<label>numero de contacto</label>
						<input type="number" class="form-control" name="n_contacto" maxlength="11">
					</div>
					<div class="form-group">
						<label>correo</label>
						<input type="email" class="form-control" name="correo" maxlength="120">
					</div>
					<input type="submit" style="border-radius:5px; margin: 5px;" value="buscar" name="buscarUsuarios">
				</div>
			</div>';
		}
		if($busqueda=='libros'){
			echo form_open('biblioteca/busqueda').
			'<div class="panel panel-default">
				<div class="panel-heading"><h3>Busqueda de libros</h3></div>
				<div class="panel-body">
					<div class="form-group">
						<label>ISBN</label>
						<input type="name" maxlength="120" name="isbn" class="form-control">
					</div>
					<div class="form-group">
						<label>Titulo</label>
						<input type="name" maxlength="255" name="titulo" class="form-control"> 
					</div>
					<div class="form-group">
						<label>Autor</label>
						<input type="name" maxlength="120" name="autor" class="form-control">
					</div>
					<div class="form-group">
						<label>paginas</label>
						<input type="name" maxlength="11" name="paginas" class="form-control"> 
					</div>
					<div class="form-group">
						<label>CDU</label>
						<input type="name" maxlength="120" name="cdu" class="form-control">
					</div>
					<div class="form-group">
						<label>año de publicacion</label>
						<input type="number" maxlength="11" name="fecha_p" class="form-control">
					</div>
					<input type="submit" style="border-radius:5px; margin: 5px;" value="buscar" name="buscarLibros">
				</div>
			</div>';
		}
		if($busqueda=='ejemplares'){
			echo form_open('biblioteca/busqueda',$attributes).
			'<div class="panel panel-default">
				<div class="panel-heading"><h3>Busqueda de ejemplares</h3></div>
				<div class="panel-body">
					<div class="form-group">
						<label>Codigo de ejemplar</label>
						<input type="name" name="cod_ejemplar" maxlength="120" class="form-control">
					</div>
					<div class="form-group">
						<label>Isbn del ejemplar</label>
						<input type="name" name="isbn" maxlength="120" class="form-control">
					</div>
					<div class="form-group">
						<label>titulo del ejemplar</label>
						<input type="name" name="titulo" maxlength="120" class="form-control">
					</div>
					<div class="form-group">
						<label>Estado</label>
						<input type="name" name="estado" maxlength="120" class="form-control">
					</div>
					<input type="submit" style="border-radius:5px; margin: 5px;" value="buscar" name="buscarEjemplares">
				</div>
			</div>';
		}
		if($busqueda=='prestamos'){
			echo form_open('biblioteca/busqueda').
			'<div class="panel panel-default">
				<div class="panel-heading"><h3>Busqueda de prestamos</h3></div>
				<div class="panel-body">
					<div class="form-group">
						<label>Nombre de usuario</label>
						<input type="name" name="nombreUsuario" maxlength="120" class="form-control">
					</div>
					<div class="form-group">
						<label>Apellidos del usuario</label>
						<input type="name" name="apellidosUsuario" maxlength="255" class="form-control">
					</div>
					<div class="form-group">
						<label>Codigo del ejemplar</label>
						<input type="name" name="codigoEjemplar" maxlength="120" class="form-control">
					</div>
					<div class="form-group">
						<label>fecha de inicio</label>
						<input type="name" name="fechaInicio" maxlength="120" placeholder="DD-MM-YYYY" class="form-control">
					</div>
					<div class="form-group">
						<label>fecha de finalizacion</label>
						<input type="name" name="fechaFin" maxlength="120" placeholder="DD-MM-YYYY"  class="form-control">
					</div>
					<input type="submit" style="border-radius:5px; margin: 5px;" value="buscar" name="buscarPrestamos">
				</div>
			</div>';
		}
	}
	?>
</table>