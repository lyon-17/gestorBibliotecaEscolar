<?php
$this->load->helper('form');
echo validation_errors();

$atributtes = array(
	'class' => 'form-inline',
	);
$activos = array(
	'name' => 'activos',
	'class' => 'form-control',
	'value' => 'ver prestamos activos no gratuitos',
	);
$terminados = array(
	'name' => 'terminados',
	'class' => 'form-control',
	'value' => 'ver prestamos terminados',
	);
$gratuitos = array(
	'name' => 'gratuitos',
	'class' => 'form-control',
	'value' => 'ver los prestamos gratuitos',
	);
$todos = array(
	'name' => 'todos',
	'class' => 'form-control',
	'value' => 'ver todos los prestamos',
	);

echo '<br/>'.form_open('biblioteca/indexPrestamos',$atributtes).form_submit($activos).form_submit($gratuitos).form_submit($terminados).form_submit($todos).'
	</form><br/>
	<div class="panel panel-default">
			<div class="panel-heading"><h3>'.$title.'</h3></div>
				<div class="panel-body">
	<table class="table table-striped table-hover table-condesed">
		<tr>
			<th>Id del prestamo</th>
			<th>Nombre del usuario</th>
			<th>Apellidos del usuario</th>
			<th>Codigo del ejemplar</th>
			<th>Fecha de inicio</th>
			<th>Fecha de finalizacion</th>
		</tr>';
		foreach ($prestamos as $prestamos_item):
		$fecha = date('d-m-Y', strtotime($prestamos_item['fecha_inicio']));
		$fechaFin = date('d-m-Y', strtotime($prestamos_item['fecha_fin']));
		if($fechaFin == '01-01-1970' || !$fechaFin){
			$fechaFin = 'Sin fecha';
		}
		echo '<tr>
				<td>' . $prestamos_item['id_prestamo'].'</td>
				<td>' . $prestamos_item['nombre'].'</td>
				<td>' . $prestamos_item['apellidos'].'</td>
				<td>' . $prestamos_item['ejemplares_cod_ejemplar'].'</td>
				<td>' . $fecha.'</td>
				<td>' . $fechaFin.'</td>';
		echo '</tr>';

		endforeach;
	
	echo '	</table>
		</div>
	</div>';
	?>
</table>